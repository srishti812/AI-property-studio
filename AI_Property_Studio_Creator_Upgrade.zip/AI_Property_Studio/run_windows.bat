@echo off
cd /d "%~dp0"
if not exist .venv (
  py -3.13 -m venv .venv
)
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m streamlit run app.py
pause
